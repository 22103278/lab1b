//
// Created by metinu on 9/19/17.
//

#ifndef DIJKSTRA_GRAPH_DRAWER_H
#define DIJKSTRA_GRAPH_DRAWER_H
#include "dijkstra.h"
void draw_solution_to_image(struct Dijkstra_input *input, struct Dijkstra_output *output, char *filename_out);
#endif //DIJKSTRA_GRAPH_DRAWER_H
